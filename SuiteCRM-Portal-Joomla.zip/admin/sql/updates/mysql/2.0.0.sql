ALTER TABLE `#__advancedopenportal`
  ADD COLUMN allow_case_reopen BOOLEAN,
  ADD COLUMN  allow_case_closing BOOLEAN,
  ADD COLUMN  allow_priority BOOLEAN,
  ADD COLUMN  allow_type BOOLEAN;

