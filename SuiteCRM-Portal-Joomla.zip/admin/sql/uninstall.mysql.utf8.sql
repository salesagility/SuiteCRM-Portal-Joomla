DROP TABLE IF EXISTS `#__advancedopenportal`;
