<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
    <td>
        &nbsp;
    </td>
    <td>
        <button class="submit" type="submit" name="submit">Save Settings</button>
    </td>
</tr>
