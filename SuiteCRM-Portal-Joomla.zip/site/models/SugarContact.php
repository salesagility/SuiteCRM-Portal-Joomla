<?php

class SugarContact {

    private $id;

    public function __construct($id){
        $this->id = $id;
    }

    public function fetch(){

    }



}