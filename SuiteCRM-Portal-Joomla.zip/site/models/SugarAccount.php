<?php

class SugarAccount {

    public function __construct($num,$account_array){
        //Build up account based on array

        //Do records
        if(isset($accounts['relationship_list'][$num][0]['records'])){
            foreach($accounts['relationship_list'][$num][0]['records'] as $case){

            }
        }
    }

}